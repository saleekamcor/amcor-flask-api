from flask import Flask, request, jsonify, abort, send_from_directory
import os, json

app = Flask(__name__)

DATA_DIR = r"C:\Users\fila\newdashboard"
ARTNO_FOLDER = os.path.join(DATA_DIR, "artno_files")

API_KEY = "your-strong-secret-key" # Change to a strong key

# List all your central files here
DEFAULTS = {
    "orders.json": [],
    "order_sizes.json": {},
    "jobcards.json": [],
    "sizes.json": [],
    "unsizes.json": [],
    "customers.json": [],
    "vendors.json": [],
    "items.json": [],
    "artnos.json": [],
    "fabrics.json": [],
    "priority_customers.json": [],
    "production.json": [],
    "jobwork_out.json": [],
    "jobwork_in.json": [],
    "vendor_payments.json": [],
    "dummycards.json": [],
    "cad_marker_entries.json": [],
    "delivered.json": [],
    "logo_embroidery.json": [],
    "fabric_ledger.json": [],
    "users.json": [],
    "activity_log.json": [],
    ".last_selected_pro": "",
    ".edit_production_row.json": {},
}

def check_auth():
    if request.headers.get("X-API-KEY") != API_KEY:
        abort(403)

@app.route("/")
def home():
    return "Amcor Flask API is running", 200

@app.route("/ping")
def ping():
    return "pong", 200

@app.route("/read/<filename>", methods=["GET"])
def read_file(filename):
    check_auth()
    fn = os.path.join(DATA_DIR, filename)
    if not os.path.exists(fn):
        # Return default content if file missing
        default_content = DEFAULTS.get(filename, {})
        return jsonify(default_content), 200
    with open(fn, "r", encoding="utf-8") as f:
        try:
            data = json.load(f)
        except Exception:
            return jsonify({"error": "Corrupt or invalid file"}), 500
    return jsonify(data), 200

@app.route("/write/<filename>", methods=["POST"])
def write_file(filename):
    check_auth()
    fn = os.path.join(DATA_DIR, filename)
    data = request.json
    with open(fn, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    return jsonify({"status": "ok"}), 200

# ----------- ARTNO FILE UPLOAD/DOWNLOAD API ----------------
@app.route("/upload_artno", methods=["POST"])
def upload_artno():
    check_auth()
    if "file" not in request.files or "artno" not in request.form:
        return jsonify({"error": "File and artno required"}), 400
    file = request.files["file"]
    artno = request.form["artno"].strip()
    if not artno or not file:
        return jsonify({"error": "Missing file or artno"}), 400
    ext = os.path.splitext(file.filename)[1].lower()
    filename = f"ARTNO_{artno}{ext}"
    save_path = os.path.join(ARTNO_FOLDER, filename)
    file.save(save_path)
    return jsonify({"filename": filename}), 200

@app.route("/get_artno/<filename>", methods=["GET"])
def get_artno(filename):
    check_auth()
    return send_from_directory(ARTNO_FOLDER, filename, as_attachment=False)

# ----------- LIST ALL FILES + TIMESTAMPS (for syncing) -----------
@app.route("/list_files", methods=["GET"])
def list_files():
    check_auth()
    files = {}
    # List JSON files
    for fname in os.listdir(DATA_DIR):
        path = os.path.join(DATA_DIR, fname)
        if os.path.isfile(path):
            files[fname] = {
                "mtime": int(os.path.getmtime(path)),
                "size": os.path.getsize(path)
            }
    # List ARTNO files
    for fname in os.listdir(ARTNO_FOLDER):
        path = os.path.join(ARTNO_FOLDER, fname)
        if os.path.isfile(path):
            files[f"artno_files/{fname}"] = {
                "mtime": int(os.path.getmtime(path)),
                "size": os.path.getsize(path)
            }
    return jsonify(files)

def ensure_data_files():
    os.makedirs(DATA_DIR, exist_ok=True)
    for fname, default_content in DEFAULTS.items():
        path = os.path.join(DATA_DIR, fname)
        if not os.path.exists(path):
            with open(path, "w", encoding="utf-8") as f:
                json.dump(default_content, f, indent=2)

def ensure_art_files():
    os.makedirs(ARTNO_FOLDER, exist_ok=True)

if __name__ == "__main__":
    ensure_data_files()
    ensure_art_files()
    app.run(host="0.0.0.0", port=8000)
